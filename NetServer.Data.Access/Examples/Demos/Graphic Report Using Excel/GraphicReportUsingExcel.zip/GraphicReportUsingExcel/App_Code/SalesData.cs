using System;
using System.Collections.Generic;
using System.Text;

namespace GraphicReportUsingExcel
{
    //The Container class for the Sale information
    public class SalesData
    {        
        string _proName;
        string _SalAmnt;
        string _SalEarnPer;

        //Class constructor
        public SalesData(string proName, string salAmnt, string salEarnPer)
        {            
            _proName = proName;
            _SalAmnt = salAmnt;
            _SalEarnPer = salEarnPer;
        }

        //Conversion methods for each property   
        [Conversion(ConvertDataTable = true, KeyFields = true, DBNull = false)]
        public string ConName
        {
            get { return _proName; }
            set { _proName = value; }
        }

        [Conversion(ConvertDataTable = true, KeyFields = true, DBNull = false)]
        public string SalAmnt
        {
            get { return _SalAmnt; }
            set { _SalAmnt = value; }
        }

        [Conversion(ConvertDataTable = true, KeyFields = true, DBNull = false)]
        public string SalEarnPer
        {
            get { return _SalEarnPer; }
            set { _SalEarnPer = value; }
        }        
    }
}
