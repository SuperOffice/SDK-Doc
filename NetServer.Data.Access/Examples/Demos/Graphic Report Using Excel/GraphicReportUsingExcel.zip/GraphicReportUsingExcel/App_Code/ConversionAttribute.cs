using System;
using System.Collections.Generic;
using System.Text;

namespace GraphicReportUsingExcel
{
    // The following class allows us to obtain meta data about the properties of the
    //Container class. 
    [AttributeUsage(AttributeTargets.Property)]
    public class ConversionAttribute : Attribute
    {
        //Variable declaration
        private bool _dataTabCon;
        private bool _DBNull;
        private bool _KyFields;

        //Class Contructor
        public ConversionAttribute() { }

        //Get / Set Methods
        public bool ConvertDataTable
        {
            get { return _dataTabCon; }
            set { _dataTabCon = value; }
        }
        public bool DBNull
        {
            get { return _DBNull; }
            set { _DBNull = value; }
        }
        public bool KeyFields
        {
            get { return _KyFields; }
            set { _KyFields = value; }
        }
    }
}
