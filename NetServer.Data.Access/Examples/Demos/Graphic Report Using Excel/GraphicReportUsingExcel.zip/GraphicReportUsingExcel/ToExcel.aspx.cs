using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Data.OleDb;
using System.Xml;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;

using SuperOffice.CRM.ArchiveLists;
using SuperOffice.CRM.Archives;
using SuperOffice;
using SuperOffice.CRM.Services;
using GraphicReportUsingExcel;
using SuperOffice.CRM.Globalization;

public partial class ToExcel : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            using (SoSession newSession = SoSession.Authenticate("sam", "sam"))
            {
                //Setting the Parameters that needs to be passed to Agent method   
                //Parameter - providerName - The name of the archive provider to use
                IArchiveProvider newSalePro = new SaleProvider();

                //Parameter - columns - An array of the names of the columns wanted.
                string[] columns = new string[] { "project/name", "amount", "earningPercent" };
                newSalePro.SetDesiredColumns(columns);

                //Parameter - entities - Which entities to include
                string[] entities = new string[] { "sale", "contact" };
                newSalePro.SetDesiredEntities(entities);

                //Parameter - restriction - Archive restrictions
                ArchiveRestrictionInfo[] archiveRest = new ArchiveRestrictionInfo[1];
                archiveRest[0] = new ArchiveRestrictionInfo("contactid", "=", "4");
                newSalePro.SetRestriction(archiveRest);

                //Parameter - page - Page number, page 0 is the first page
                //Parameter - pageSize - Page size   
                int page = 1;
                int pageSize = 10;
                newSalePro.SetPagingInfo(pageSize, page);

                //Parameter - sortOrder - Sort order for the archive
                ArchiveOrderByInfo[] archiveSrtOrd = new ArchiveOrderByInfo[1];
                archiveSrtOrd[0] = new ArchiveOrderByInfo("project/name", SuperOffice.Util.OrderBySortType.DESC);
                newSalePro.SetOrderBy(archiveSrtOrd);

                //Converting the data into an acceptable form 
                CoreWebList<SalesData> coreWebTestList = new CoreWebList<SalesData>();
                foreach (ArchiveRow row in newSalePro.GetRows())
                {
                    ArrayList frArrLst = new ArrayList();
                    foreach (KeyValuePair<string, ArchiveColumnData> column in row.ColumnData)
                    {
                        string displayValue = column.Value != null ? column.Value.DisplayValue.ToString() : "-";
                        frArrLst.Add(displayValue);
                    }
                    SalesData frSaleData = new SalesData(frArrLst[0].ToString(), frArrLst[1].ToString(), frArrLst[2].ToString());
                    coreWebTestList.Add(frSaleData);
                    frArrLst.Clear();
                }

                //Coverting the data which can be used to construct Excel Graphs
                DataTable newDataTbl = (DataTable)coreWebTestList;
                DataTable newDataTbl2 = new DataTable();
                newDataTbl2.TableName = "Sales Information";
                newDataTbl2.Columns.Add("Project Name");
                newDataTbl2.Columns.Add("Amount");
                newDataTbl2.Columns.Add("Earning %");                
                foreach (DataRow datRow in newDataTbl.Rows)
                {
                    DataRow dr = newDataTbl2.NewRow();
                    dr[0] = datRow.ItemArray[0].ToString();
                    dr[1] = float.Parse(datRow.ItemArray[1].ToString().Substring(3, datRow.ItemArray[1].ToString().Length - 4));
                    dr[2] = float.Parse(datRow.ItemArray[2].ToString().Substring(3, datRow.ItemArray[2].ToString().Length - 4));
                    newDataTbl2.Rows.Add(dr);
                }

                //Write the data into the DataGrid
                DataView newDateView = new DataView(newDataTbl2);
                GridView1.DataSource = newDateView;
                GridView1.DataBind();

                //Write the Data into an XML file using the XmlTextWriter class
                FileStream newFs = new FileStream("C:\\SaleData.xml", FileMode.Create);
                XmlTextWriter newTextWriter = new XmlTextWriter(newFs, Encoding.Unicode);
                //newTextWriter.WriteProcessingInstruction("xml-stylesheet", "type='text/xsl' href='Sales.xsl");
                newDataTbl2.WriteXml(newTextWriter);
            }
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }    
}
