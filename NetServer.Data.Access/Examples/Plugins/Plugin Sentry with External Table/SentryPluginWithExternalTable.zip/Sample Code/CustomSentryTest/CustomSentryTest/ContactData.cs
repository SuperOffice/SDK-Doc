using System;
using System.Collections.Generic;
using System.Text;

namespace CustomSentryTest
{
    public class ContactData
    {
        #region private properties

        int _id;
        string _name;
        string _department;

        #endregion


        //class constructor
        public ContactData(int ContactId, string Name, string Department)
        {
            _id = ContactId;
            _name = Name;
            _department = Department;        
        }


        # region public class properties

        // Contact id
        public int ContactId
        {
            get { return _id; }
            set { _id = value; }
        }

        // the contact name 
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

       // the contact department
        public string Department
        {
            get { return _department; }
            set { _department = value; }
        }

     
        #endregion

    }
   
}
