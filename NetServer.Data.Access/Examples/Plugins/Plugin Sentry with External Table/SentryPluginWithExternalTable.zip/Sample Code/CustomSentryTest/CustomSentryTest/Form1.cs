using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using SuperOffice.CRM.Data;
using SuperOffice.Data;
using SuperOffice.Data.SQL;
using SuperOffice;
using System.Collections.Specialized;
using System.Collections;



namespace CustomSentryTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


    private void btnShowContacts_Click(object sender, EventArgs e)
    {
        try
        {
            using (SoSession session = SoSession.Authenticate(this.txtUserName.Text.Trim(), this.txtPWD.Text.Trim()))
            {
               
                // Retrive tableInfo for the ContactTable
                ContactTableInfo newConTable = TablesInfo.GetContactTableInfo();

                // Retrieve Data from a the tables in to an instance of the Select Class
                Select newSelect = S.NewSelect();

                // Choose the columns that should be retrieved
                newSelect.ReturnFields.Add(newConTable.ContactId, newConTable.Department, newConTable.Name);

                // Order the retrieved Data
                newSelect.OrderBy.SortOrder.Add(newConTable.ContactId, SuperOffice.Util.OrderBySortType.ASC);

                // Establish a Database Connection
                SoConnection myConn = ConnectionFactory.GetConnection();

                // Create SoCommand instance and assigning the Select statement
                SoCommand myComm = myConn.CreateCommand();
                myComm.SqlCommand = newSelect;
                myConn.Open();

                // Load the data into the DataReader
                SoDataReader myReader = myComm.ExecuteReader();

                ArrayList arrConData = new ArrayList();                    

                // Retrieve the data from the reader
                while (myReader.Read())
                {
                    int conID = myReader.GetInt32(0);                       
                    string conDept = myReader.GetString(1);
                    string conName = myReader.GetString(2);
                    // Create a user defined contact object to be stored in the ArrayList
                    ContactData contact = new ContactData(conID, conName, conDept);
                    arrConData.Add(contact);
                }

                // Setting the results to the data grid
                this.grdContactData.DataSource = arrConData;

                // Close the Reader 
                myReader.Close();

            }
        }
        catch (Exception exception) 
        {
            // Clear textboxes and the data grid
            this.clearAll();
            MessageBox.Show("Invalid user."); 
        }
    }


        private void btnClear_Click(object sender, EventArgs e)
        {
            this.clearAll();
        }

        /// <summary>
        /// Clear the controls
        /// </summary>
        private void clearAll() 
        {
            this.txtPWD.Text = "";
            this.txtUserName.Text = "";
            this.grdContactData.DataSource = null;
        }

       
    }
}