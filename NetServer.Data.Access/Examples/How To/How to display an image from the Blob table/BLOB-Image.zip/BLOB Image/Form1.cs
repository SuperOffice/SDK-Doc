using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


using System.IO;

using SuperOffice;
using SuperOffice.CRM.Rows;
using SuperOffice.Data;
using SuperOffice.CRM.Data;


namespace BLOB_Image
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            DisplayImageList();
        }

        //Method that displays the Image decription on the Listbox
        private void DisplayImageList()
        {
            try
            {
                using (SoSession newSoSession = SoSession.Authenticate("sam", "sam"))
                {
                    //Retrieves a set of BinaryObjectRows whose MimeType = "image/jpeg"
                    BinaryObjectRows newBinObjRws = BinaryObjectRows.GetFromIdxMimeType("image/jpeg");

                    //Displays a list of Images Avalable
                    foreach (BinaryObjectRow newBinObjRw in newBinObjRws)
                    {                 
                        //Display the image description in the Listbox
                        listBox1.Items.Add(newBinObjRw.Description);                        
                    }   
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }        

        //Method that is ivoked when a item is selected from the Listbox
        private void listBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                using (SoSession newSoSession = SoSession.Authenticate("sam", "sam"))
                {
                    //Instantiate a BinaryRowObject CustomSearch
                    BinaryObjectRow.CustomSearch newCusSearch = new BinaryObjectRow.CustomSearch();

                    //Instantiate BinaryObjectTableInfo class using the created CustomSearch
                    BinaryObjectTableInfo newBinObjTabInf = newCusSearch.TableInfo;

                    //Restricts the BinaryObjectTableInfo
                    newCusSearch.Restriction = newBinObjTabInf.Description.Equal(S.Parameter(listBox1.SelectedItem.ToString())).
                        And(newBinObjTabInf.MimeType.Equal(S.Parameter("image/jpeg")));

                    //Retrieves the BinaryObjectRow basedon the CustomSearch
                    BinaryObjectRow newBinObjRw = BinaryObjectRow.GetFromCustomSearch(newCusSearch);

                    //Gets the BinaryObjectRow's image into the stream and display it
                    Stream newStream = newBinObjRw.BinaryData;
                    pictureBox1.Image = Image.FromStream(newStream);     
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}