using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using SuperOffice.CRM.Entities;
using SuperOffice;
using SuperOffice.CRM.Rows;
using SuperOffice.CRM.Globalization;


namespace SetUDefinedListItemOnUdefFieldOnContact
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSaveContact_Click(object sender, EventArgs e)
        {
            using (SoSession newSession = SoSession.Authenticate("p", "p"))
            {
                if (!(String.IsNullOrEmpty(txtContactId.Text.Trim())))
                {
                    Contact contact = Contact.GetFromIdxContactId(int.Parse(txtContactId.Text.Trim()));
                    if (contact != null)
                    {
                        // Get the prodId of the udefField of interest
                        string progId=contact.UdefHelper.GetProgIdFromFieldLabel("companydropdownlistbox");

                        // Modify the value for the udef field for the current contact to the selected value 
                        contact.UdefHelper.SetValue(progId,this.lstFieldList.SelectedValue);                           

                        // Save the contact details
                        contact.Save();
                        MessageBox.Show("Contact details saved sucessfully.");                        
                    }
                }
                else
                {
                    MessageBox.Show("Please enter the contact id.");
                }
            }            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        
        private void btnGetContact_Click(object sender, EventArgs e)
        {
            using (SoSession newSession = SoSession.Authenticate("p", "p"))
            {
                if (!(String.IsNullOrEmpty(txtContactId.Text.Trim())))
                {
                    // Get the contact
                    Contact contact = Contact.GetFromIdxContactId(int.Parse(txtContactId.Text.Trim()));
                    if (contact != null)
                    {
                        this.lblContactName.Text = contact.Name;

                        // Get the progId of the user defined field 'companydropdownlistbox'
                        string progId = contact.UdefHelper.GetProgIdFromFieldLabel("companydropdownlistbox");                      

                        // Get the User-DefinedField
                        UDefFieldRow udefField = UDefFieldCache.GetFromProgId(progId, SuperOffice.Data.UdefHelper.UDefType.Contact);               
                        
                        // Get the list name                        
                        UDListDefinitionRow udRow =UDListDefinitionRow.GetFromIdxUDListDefinitionId(udefField.UDListDefinitionId);
                        MessageBox.Show(udRow.Name);

                        // Get the list table id and identify the base table
                        short listId = udefField.ListTableId;                         

                        // Get the list from the base table
                        TaskRows.CustomSearch newTaskCus = new TaskRows.CustomSearch();                   
                        TaskRows newTasks = TaskRows.GetFromCustomSearch(newTaskCus);

                        // Set the list items
                        this.lstFieldList.DataSource = newTasks;
                        this.lstFieldList.DisplayMember ="Name";
                        this.lstFieldList.ValueMember = "TaskId";    
                    }
                }
                else
                {
                    MessageBox.Show("Please enter the contact id.");
                }
            }
        }

        private void lstFieldList_SelectedIndexChanged(object sender, EventArgs e)
        {
           // Set the selected value     
           TaskRow selectedRow = (TaskRow)(this.lstFieldList.SelectedItem);       
           this.txtFieldValue.Text = selectedRow.Name;
        }
        
    }
}