namespace SetUdefListItem
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblContactName = new System.Windows.Forms.Label();
            this.btnSaveContact = new System.Windows.Forms.Button();
            this.lstFieldList = new System.Windows.Forms.ListBox();
            this.btnGetContact = new System.Windows.Forms.Button();
            this.txtFieldValue = new System.Windows.Forms.TextBox();
            this.txtContactId = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 143);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "List";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(142, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 24;
            this.label5.Text = "Udlist one";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "User-Defined Field Name";
            // 
            // lblContactName
            // 
            this.lblContactName.AutoSize = true;
            this.lblContactName.Location = new System.Drawing.Point(140, 42);
            this.lblContactName.Name = "lblContactName";
            this.lblContactName.Size = new System.Drawing.Size(0, 13);
            this.lblContactName.TabIndex = 22;
            // 
            // btnSaveContact
            // 
            this.btnSaveContact.Location = new System.Drawing.Point(143, 309);
            this.btnSaveContact.Name = "btnSaveContact";
            this.btnSaveContact.Size = new System.Drawing.Size(100, 23);
            this.btnSaveContact.TabIndex = 21;
            this.btnSaveContact.Text = "Save Contact";
            this.btnSaveContact.UseVisualStyleBackColor = true;
            this.btnSaveContact.Click += new System.EventHandler(this.btnSaveContact_Click);
            // 
            // lstFieldList
            // 
            this.lstFieldList.FormattingEnabled = true;
            this.lstFieldList.Location = new System.Drawing.Point(143, 143);
            this.lstFieldList.Name = "lstFieldList";
            this.lstFieldList.Size = new System.Drawing.Size(253, 160);
            this.lstFieldList.TabIndex = 20;
            this.lstFieldList.SelectedIndexChanged += new System.EventHandler(this.lstFieldList_SelectedIndexChanged);
            // 
            // btnGetContact
            // 
            this.btnGetContact.Location = new System.Drawing.Point(252, 7);
            this.btnGetContact.Name = "btnGetContact";
            this.btnGetContact.Size = new System.Drawing.Size(75, 23);
            this.btnGetContact.TabIndex = 19;
            this.btnGetContact.Text = "Get Contact";
            this.btnGetContact.UseVisualStyleBackColor = true;
            this.btnGetContact.Click += new System.EventHandler(this.btnGetContact_Click);
            // 
            // txtFieldValue
            // 
            this.txtFieldValue.Location = new System.Drawing.Point(143, 108);
            this.txtFieldValue.Name = "txtFieldValue";
            this.txtFieldValue.Size = new System.Drawing.Size(253, 20);
            this.txtFieldValue.TabIndex = 18;
            // 
            // txtContactId
            // 
            this.txtContactId.Location = new System.Drawing.Point(143, 9);
            this.txtContactId.Name = "txtContactId";
            this.txtContactId.Size = new System.Drawing.Size(100, 20);
            this.txtContactId.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "User-Defined Field Value";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "Contact Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Contact Id";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(404, 338);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblContactName);
            this.Controls.Add(this.btnSaveContact);
            this.Controls.Add(this.lstFieldList);
            this.Controls.Add(this.btnGetContact);
            this.Controls.Add(this.txtFieldValue);
            this.Controls.Add(this.txtContactId);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Set a user-defined list item on a udef field";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblContactName;
        private System.Windows.Forms.Button btnSaveContact;
        private System.Windows.Forms.ListBox lstFieldList;
        private System.Windows.Forms.Button btnGetContact;
        private System.Windows.Forms.TextBox txtFieldValue;
        private System.Windows.Forms.TextBox txtContactId;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

