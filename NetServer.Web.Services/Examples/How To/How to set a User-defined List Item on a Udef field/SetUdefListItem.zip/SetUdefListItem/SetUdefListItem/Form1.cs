using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using SuperOffice;
using SuperOffice.CRM.Services;

namespace SetUdefListItem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSaveContact_Click(object sender, EventArgs e)
        {
            using (SoSession newSession = SoSession.Authenticate("p", "p"))
            {
                if (!(String.IsNullOrEmpty(txtContactId.Text.Trim())))
                {
                    // Create a Contact Agent
                    IContactAgent agent = AgentFactory.GetContactAgent();

                    // Get a Contact Entity through the Contact Agent    
                    ContactEntity contactEntity = agent.GetContactEntity(int.Parse(txtContactId.Text.Trim()));
                    if (contactEntity != null)
                    {
                        // Create a IUserDefinedFieldInfoAgent
                        IUserDefinedFieldInfoAgent udefFieldInfoAgent = AgentFactory.GetUserDefinedFieldInfoAgent();

                        // Get the UserDefinedFieldInfo of 'Udlist one' through the IUserDefinedFieldInfoAgent
                        UserDefinedFieldInfo udefFieldInfo = udefFieldInfoAgent.GetUserDefinedFieldFromFieldLabel("Udlist one", 7);

                        // Get the ProgId of the udefField 
                        string progId = udefFieldInfo.ProgId;

                        // Get the UserDefinedFields collection for the current contact
                        StringDictionary dictionary = contactEntity.UserDefinedFields;

                        // Set the selected value on the listbox to the udefField value  
                        dictionary[progId] = this.lstFieldList.SelectedValue.ToString();

                        // Save the contact details
                        agent.SaveContactEntity(contactEntity);
                        MessageBox.Show("Contact details saved sucessfully.");
                        this.clearContents();
                    }
                }
                else
                {
                    MessageBox.Show("Please enter the contact id.");
                }
            }
        }


        private void btnGetContact_Click(object sender, EventArgs e)
        {
            using (SoSession newSession = SoSession.Authenticate("p", "p"))
            {
                if (!(String.IsNullOrEmpty(txtContactId.Text.Trim())))
                {
                    // Create a Contact Agent
                    IContactAgent agent = AgentFactory.GetContactAgent();
                    // Get a Contact Entity through the Contact Agent    
                    ContactEntity contactEntity = agent.GetContactEntity(int.Parse(txtContactId.Text.Trim()));

                    if (contactEntity != null)
                    {
                        this.lblContactName.Text = contactEntity.Name;

                        // Create a IUserDefinedFieldInfoAgent
                        IUserDefinedFieldInfoAgent udefFieldInfoAgent = AgentFactory.GetUserDefinedFieldInfoAgent();

                        // Get the UserDefinedFieldInfo of 'Udlist one' through the IUserDefinedFieldInfoAgent                       
                        UserDefinedFieldInfo udefFieldInfo = udefFieldInfoAgent.GetUserDefinedFieldFromProgId("SuperOffice:12", 7);

                        // Create MDOAgent
                        IMDOAgent mdoAgent = AgentFactory.GetMDOAgent();

                        // Get the MDOListItems array for the given udef field - Udlist one
                        MDOListItem[] userDefinedListItems = mdoAgent.GetList("udlist", true, udefFieldInfo.UDListDefinitionId.ToString(), false);

                        // Set the list items
                        this.lstFieldList.DataSource = userDefinedListItems;
                        this.lstFieldList.DisplayMember = "Name";
                        this.lstFieldList.ValueMember = "Id";
                    }
                }
                else
                {
                    MessageBox.Show("Please enter the contact id.");
                }
            }
        }

        private void lstFieldList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.lstFieldList.SelectedIndex > -1)
            {
                // Set the selected value     
                MDOListItem selectedTask = (MDOListItem)(this.lstFieldList.SelectedItem);
                this.txtFieldValue.Text = selectedTask.Name;
            }
        }

        private void clearContents()
        {
            this.txtContactId.Text = "";
            this.txtFieldValue.Text = "";
            this.lblContactName.Text = "";
            this.lstFieldList.DataSource = null;
        }

       
       
    }
}