using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using SuperOffice;
using SuperOffice.CRM.Services;


public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LoginBtn_Click(object sender, EventArgs e)
    {
        //Retriving the user name and password and assigning them to Session variables
        Session["UserName"] = soLogin.UserName; 
        Session["passWord"] = soLogin.Password;

        using (SoSession mySession = SoSession.Authenticate(Session["UserName"].ToString(), Session["passWord"].ToString()))
        {
            //Transferring to the Appointments page - this is not a HTTP redirect, but a GOSUB in process
            Server.Transfer("Appointments.aspx");
        }

    }
}
