﻿using System;
using SuperOffice.Data;
using SuperOffice.CRM.Web;

namespace ControlsAndDataHandlers
{
    public partial class PersonalColorPreference : SuperOffice.CRM.Web.UI.Controls.UserControlBase
    {
        public string PersonDataSourceName { get; set; }
        public string UDFieldProgId { get; set; }
        public string UDListId { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            ddlColors.Items.Add("Select One");
            Array.ForEach(Enum.GetNames(typeof(BasicColor)), delegate(string color) { this.ddlColors.Items.Add(color);});
        }

        public override void Initialize(System.Xml.XmlNode config, string id)
        {
            base.Initialize(config, id);
        }

        public override void DataBind()
        {

            PersonalColorCarrier colorCarrier = (PersonalColorCarrier)this.DataSource;

            if (colorCarrier != null)
            {
                this.lblActualName.Text = colorCarrier.Name;
                this.ddlColors.SelectedIndex = (int)colorCarrier.SelectedColor;
            }
        }

        public override void UpdateDataSource()
        {
            //Make changes to this.DataSource
            //the changes will then be seen in DataHandler.Save method.
        }
    }
}