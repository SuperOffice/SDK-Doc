Create a link to the following config files and add/modify sections accordingly:

1. SoApplicationConfiguration.config

	Add the following two page declarations to SoApplicationConfiguration.config.

		<!--Start DevNet-->
		<page id="personalcolor" type="dialog" height="400px" width="400px" />
		<page id="personalinformation" type="dialog" height="400px" width="400px" />
		<!--End DevNet-->

2. SoObjectMapping.config
	
	Add the following object elements to the SoObjectMapping.config file.

		<object type="IDataHandler" mappingname="PersonalColorDataHandler" assemblyname="ControlsAndDataHandlers" objectname="ControlsAndDataHandlers.PersonalColorDataHandler"></object>
		<object type="UserControl" mappingname="PersonalColorUserControl" assemblyname="ControlsAndDataHandlers" objectname="~/UserControls/PersonalColorPreference.ascx"></object>
		<object type="UserControl" mappingname="PersonalInfoUserControl" assemblyname="ControlsAndDataHandlers" objectname="~/UserControls/PersonalInformation.ascx"></object>

3. SoPersonalInformationPage.config and SoPersonalColorPage.config

	Add these two files to the webroot\App_Data\WebClient\Web folder.
	
4. SoNavigatorPanel.config

	Add two child control entries to the ButtonGroup controlgroup/controls element.
	These entries will display two new buttons in the navigator pane that open the new pages.
	
        <control id="personalinfobutton1" type="SoToolButton">
          <caption>Personal Color: BuiltIn</caption>
          <tooltip>Open Personal Color Page</tooltip>
          <config>
            <onclick>javascript:Dialog.open("personalcolor", "personalcolor[dialog=stop]");</onclick>
            <ontextclick>javascript:dummy();</ontextclick>
            <passiveimage>images/icon/app_bolt_passive.gif</passiveimage>
            <disabledimage>images/icon/app_bolt_disabled.gif</disabledimage>
            <selectedimage>images/icon/app_bolt_active.gif</selectedimage>
            <hoverimage>images/icon/app_bolt_hover.gif</hoverimage>
            <width>70</width>
            <menuaccess>HyperText</menuaccess>
            <textalign>right</textalign>
          </config>
        </control>

        <control id="personalinfobutton2" type="SoToolButton">
          <caption>Personal Color: Custom</caption>
          <tooltip>Open Personal Color Page</tooltip>
          <config>
            <onclick>javascript:Dialog.open("personalinformation", "personalinformation[dialog=stop]");</onclick>
            <ontextclick>javascript:dummy();</ontextclick>
            <passiveimage>images/icon/app_bolt_passive.gif</passiveimage>
            <disabledimage>images/icon/app_bolt_disabled.gif</disabledimage>
            <selectedimage>images/icon/app_bolt_active.gif</selectedimage>
            <hoverimage>images/icon/app_bolt_hover.gif</hoverimage>
            <width>70</width>
            <menuaccess>HyperText</menuaccess>
            <textalign>right</textalign>
          </config>
        </control>	

5. Add the following to the post build event of the project.

	This assumes you have a copy of 6.web Expander Edition at C:\6web62.

		copy "$(TargetPath)" "C:\6web62\bin"
		copy "$(TargetDir)\$(TargetName).pdb" "C:\6web62\bin"
		copy "$(ProjectDir)\PersonalColorPreference.ascx" "C:\6web62\UserControls\"
		copy "$(ProjectDir)\PersonalInformation.ascx" "C:\6web62\UserControls\"	  
		
6. Add a new Folder called "UserControls" under the webroot. 
	
	This is where the *.ascx files are referenced from.